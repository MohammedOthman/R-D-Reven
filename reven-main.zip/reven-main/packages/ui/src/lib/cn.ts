import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Merge conditional class names, resolving Tailwind class conflicts sanely. */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}
